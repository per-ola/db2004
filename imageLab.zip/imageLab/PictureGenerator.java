public interface PictureGenerator {

    public String getMenuName();
    public Picture picture();

}