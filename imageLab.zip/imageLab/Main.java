public class Main {

    public static void main(String[] args) {
        ImageLabFrame f = new ImageLabFrame();
       f.setVisible(true);
    }
}
